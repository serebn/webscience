
//
//first it figures out time and date
var d = new Date();
var m = d.getMonth();
var d = new Date();
var month = new Array();
month[0] = "January";
month[1] = "February";
month[2] = "March";
month[3] = "April";
month[4] = "May";
month[5] = "June";
month[6] = "July";
month[7] = "August";
month[8] = "September";
month[9] = "October";
month[10] = "November";
month[11] = "December";
var n = month[d.getMonth()];

var weekday = new Array(7);
weekday[0] =  "Sunday";
weekday[1] = "Monday";
weekday[2] = "Tuesday";
weekday[3] = "Wednesday";
weekday[4] = "Thursday";
weekday[5] = "Friday";
weekday[6] = "Saturday";
weekday[7] =  "Sunday";
weekday[8] = "Monday";
weekday[9] = "Tuesday";
var w = weekday[d.getDay()];
//then shows it to user
document.getElementById("tommorow").innerHTML = weekday[d.getDay()+1]
document.getElementById("tommorow+1").innerHTML = weekday[d.getDay()+2]
document.getElementById("tommorow+2").innerHTML = weekday[d.getDay()+3]
document.getElementById("day").innerHTML = n+" "+d.getDate();
document.getElementById("day_of_week").innerHTML=w;

//I am using api to get location
function ipLookUp () {
  $.getJSON('http://ip-api.com/json', function(location) {
    document.getElementById("country").innerHTML = location.country;
    document.getElementById("state").innerHTML = location.regionName;
    document.getElementById("city").innerHTML = location.city;
    console.log(location);
    //then it starts function to get weather data
    processMyJson(location);
  });
}
ipLookUp();


function processMyJson(json){
  //in case didn't get ip or location
  var api='https://api.darksky.net/forecast/d1c894b6d3e8ce5990f06abe1fb8a101/42.7287,-73.6683';
  api='https://api.darksky.net/forecast/d1c894b6d3e8ce5990f06abe1fb8a101/'+json.lat+','+json.lon;
  $.getJSON(api, function(data) {
    console.log(data);
    //filling up containers in html based on id
    document.getElementById("today_temp").innerHTML = data.currently.temperature+"°f";
    document.getElementById("today_sum").innerHTML = data.hourly.summary;
    document.getElementById("today_wind").innerHTML = "Wind: "+data.currently.windSpeed+" mph";
    document.getElementById("tommorow_sum").innerHTML = data.daily.data[0].summary;
    document.getElementById("tommorow+1_sum").innerHTML = data.daily.data[1].summary;
    document.getElementById("tommorow+2_sum").innerHTML = data.daily.data[2].summary;
    document.getElementById("tommorow_temp").innerHTML ="L "+data.daily.data[0].apparentTemperatureMin+"°f H "+data.daily.data[1].apparentTemperatureHigh+"°f";
    document.getElementById("tommorow+1_temp").innerHTML ="L "+data.daily.data[1].apparentTemperatureMin+"°f H "+data.daily.data[2].apparentTemperatureHigh+"°f";
    document.getElementById("tommorow+2_temp").innerHTML ="L "+data.daily.data[2].apparentTemperatureMin+"°f H "+data.daily.data[3].apparentTemperatureHigh+"°f";

    //it also changes background picture depends on weather, check it out with vpn!
    if (data.currently.icon=="rain"){
      document.getElementById("today").style.backgroundImage="url('rain.jpg')";
    }
    if (data.currently.icon=="partly-cloudy-day" || data.currently.icon=="partly-cloudy-night" || data.currently.icon=="cloudy" || data.currently.icon=="fog"){
      document.getElementById("today").style.backgroundImage="url('cloud.jpg')";
    }
    if (data.currently.icon=="snow"){
      document.getElementById("today").style.backgroundImage="url('snow.jpg')";
    }
    else{
      document.getElementById("today").style.backgroundImage="url('sun.jpg')";
    }


  });
}
