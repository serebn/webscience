README.md
Files:
index.html
script.js
PICTURES(5)

This application using 2 api, first to get location by
ip and second to get json data based on this location.
It parces json and outputs weather and forecast in good design
